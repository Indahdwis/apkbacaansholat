package com.azhar.bacaansholat.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.azhar.bacaansholat.R

class AyatKursi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ayat_kursi)
    }
}