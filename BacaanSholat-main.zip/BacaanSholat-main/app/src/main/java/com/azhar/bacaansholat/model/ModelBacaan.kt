package com.azhar.bacaansholat.model

class ModelBacaan {
    var id: String? = null
    var name: String? = null
    var arabic: String? = null
    var latin: String? = null
    var terjemahan: String? = null
}